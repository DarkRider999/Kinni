// Mirrors the backend contract (backend/src/types).

export type Category =
  | 'WRITING' | 'BUSINESS' | 'CODING' | 'IMAGE' | 'VIDEO' | 'MUSIC'
  | 'MARKETING' | 'EDUCATION' | 'DATA_ANALYSIS' | 'RESEARCH' | 'GENERAL_WRITING';

export type PromptStyle = 'PROFESSIONAL' | 'CREATIVE' | 'TECHNICAL' | 'EDUCATIONAL';

export interface PromptOptions {
  tone?: string;
  length?: string;
  format?: string;
  audience?: string;
  language?: string;
}

export interface RecommendedTool {
  id: string;
  name: string;
  vendor: string;
  description: string;
  url: string;
  reason: string;
  rank: number;
}

export interface GenerateRequest {
  rawInput: string;
  promptStyle?: PromptStyle;
  options?: PromptOptions;
  variation?: number;
  category?: Category;
  /** Logged-in users auto-save unless this is false. */
  save?: boolean;
  attachments?: AttachmentPayload[];
}

/** What the API receives for each attached file (text is extracted in the browser). */
export interface AttachmentPayload {
  name: string;
  role: 'source' | 'reference';
  kind: 'text' | 'image' | 'other';
  size?: number;
  text?: string;
  width?: number;
  height?: number;
  description?: PhotoDescription;
}

/** AI description of an uploaded photo (from /api/analyze-image). */
export interface PhotoDescription {
  subject: string;
  details: string;
  setting: string;
  composition: string;
  camera: string;
  lighting: string;
  colors: string[];
  style: string;
  mood: string;
  text: string;
  prompt: string;
}

export interface GenerateResponse {
  generatedPrompt: string;
  detectedCategory: Category;
  categoryLabel: string;
  confidence: number;
  alternativeCategories: Category[];
  recommendedTools: string[];
  toolDetails: RecommendedTool[];
  promptStyle: PromptStyle;
  detectedLanguage: string;
  variation: number;
  title: string;
  savedPromptId?: string;
  entitlement?: Entitlement | null;
}

export interface SavedPrompt {
  id: string;
  rawInput: string;
  detectedCategory: Category;
  promptStyle: PromptStyle;
  options: PromptOptions;
  generatedPrompt: string;
  recommendedTools: string[];
  title: string | null;
  isFavorite: boolean;
  createdAt: string;
}

export interface AuthUser {
  id: string;
  email: string;
  username?: string | null;
  name?: string | null;
  image?: string | null;
}

export type Plan = 'MASTER' | 'PREMIUM' | 'FREE';

export interface Entitlement {
  plan: Plan;
  freeRunsUsed: number;
  freeRunsLimit: number;
  /** null when unlimited (Master / Premium). */
  freeRunsRemaining: number | null;
  subscriptionStatus: string | null;
  currentPeriodEnd: string | null;
}

export interface ProvidersInfo {
  accountsEnabled: boolean;
  providers: Array<{ id: 'google' | 'facebook' | 'github'; label: string }>;
  billingEnabled: boolean;
  /** True when photos can be described by AI (an Anthropic API key is set). */
  visionEnabled?: boolean;
  freeRunsLimit: number;
}

export const CATEGORY_LABELS: Record<Category, string> = {
  WRITING: 'Writing', BUSINESS: 'Business', CODING: 'Coding', IMAGE: 'Image', VIDEO: 'Video',
  MUSIC: 'Music', MARKETING: 'Marketing', EDUCATION: 'Education', DATA_ANALYSIS: 'Data Analysis',
  RESEARCH: 'Research', GENERAL_WRITING: 'General Writing',
};

export const STYLE_OPTIONS: Array<{ value: PromptStyle; label: string; hint: string }> = [
  { value: 'PROFESSIONAL', label: 'Professional', hint: 'Polished, clear, business-ready' },
  { value: 'CREATIVE', label: 'Creative', hint: 'Original, vivid, story-driven' },
  { value: 'TECHNICAL', label: 'Technical', hint: 'Precise, exhaustive, structured' },
  { value: 'EDUCATIONAL', label: 'Educational', hint: 'Step-by-step, beginner-friendly' },
];
